//
// Created by tianh on 3/20/2023.
//

#ifndef SFML_PROJECT_TITLE_H
#define SFML_PROJECT_TITLE_H

#include <SFML/Graphics.hpp>
#include "Font.h"

class Title : public sf::Text  //public sf::Drawable
{
private:
    //sf::Text text;
//    sf::Font font;
public:
    Title();
//    void setPosition(float x, float y);
//    void setSize(int size);
//    void setString(std::string name);
//    virtual void draw(sf::RenderTarget& window, sf::RenderStates states) const;
};


#endif //SFML_PROJECT_TITLE_H
