//
// Created by tianh on 3/23/2023.
//

#include "AllBoxes.h"

AllBoxes::AllBoxes()
{
//    for(int i=0; i<names.size();i++)
//    {
//        push(names[i]);
//    }

}

void AllBoxes::push(const std::string& name)
{
    allBoxes.emplace_back(Box(name));
}

void AllBoxes::setPosition(sf::Vector2f position)
{
    allBoxes[0].setPosition(position);
    for(int i=1; i<allBoxes.size(); i++)
    {
        Position::boxBelow(allBoxes[i-1], allBoxes[i],5);
    }
}

sf::FloatRect AllBoxes::getGlobalBounds() const
{
    return allBoxes[0].getGlobalBounds();
}

void AllBoxes::eventHandler(sf::RenderWindow &window, sf::Event event)
{
    for(int i=0; i<allBoxes.size();i++)
    {
        allBoxes[i].eventHandler(window,event);
    }
}

void AllBoxes::draw(sf::RenderTarget &window, sf::RenderStates states) const
{
//    allBoxes[0];
    for(int i=0; i<allBoxes.size(); i++)
    {
        window.draw(allBoxes[i]);
    }
}
