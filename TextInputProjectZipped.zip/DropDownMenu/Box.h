//
// Created by tianh on 3/23/2023.
//

#ifndef SFML_PROJECT_BOX_H
#define SFML_PROJECT_BOX_H

#include <SFML/Graphics.hpp>
#include <iostream>
#include "Position.h"
#include "../Font.h"
#include "MouseEvent.h"
#include "../States.h"

class Box: public sf::Drawable, public States
{
private:
    sf::RectangleShape box;
    sf::Text text;
    sf::Font font;

    sf::Color theColor= sf::Color::Red, background= sf::Color::Yellow;

public:
    Box();
    Box(const std::string& name);

    void setText(const std::string& name);
    void setBox();
    void setPosition(sf::Vector2f position);
    sf::Vector2f getTextPosition();

    void eventHandler(sf::RenderWindow &window, sf::Event event);
    sf::FloatRect getGlobalBounds() const;

    virtual void draw(sf::RenderTarget& window, sf::RenderStates states) const;

};


#endif //SFML_PROJECT_BOX_H
