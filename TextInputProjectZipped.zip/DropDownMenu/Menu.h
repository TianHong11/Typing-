//
// Created by tianh on 3/26/2023.
//

#ifndef SFML_PROJECT_MENU_H
#define SFML_PROJECT_MENU_H
#include <SFML/Graphics.hpp>
#include "AllBoxes.h"
#include "../GUIComponent.h"
class Menu: public GUIComponent
{
private:
    Box header;
    AllBoxes options;


    Snapshot *getSnapshot() override;
    void applySnapshot(const Snapshot *snapshot) override;

public:
    Menu();
    Menu(const std::vector<std::string>& names);

    sf::FloatRect getGlobalBounds() const;
    void setPosition(sf::Vector2f position);

    void addEventHandler(sf::RenderWindow& window, sf::Event event) override;
    void update() override;
//    void eventHandler(sf::RenderWindow& window, sf::Event event);

    virtual void draw(sf::RenderTarget& window, sf::RenderStates states) const;

};


#endif //SFML_PROJECT_MENU_H
