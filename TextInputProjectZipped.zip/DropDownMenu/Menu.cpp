//
// Created by tianh on 3/26/2023.
//

#include "Menu.h"

Menu::Menu()
{

}

Menu::Menu(const std::vector<std::string>& names)
{
    header.setText(names[0]);
    header.setBox();
    for(int i=1; i<names.size();i++)
    {
        options.push(names[i]);
    }

    Position::boxBelow(header, options,20);
    options.enableStates(Hidden);
}
 void Menu::addEventHandler(sf::RenderWindow& window, sf::Event event)
{
    header.eventHandler(window,event);

    if(MouseEvent::isClicked(header, window))
    {
        options.disableStates(Hidden);
    }

        ////How is this different compared with the other one
//    else if(!MouseEvent::isClicked(header,window))
//    {
//        options.enableStates(Hidden);
//    }

    else if(MouseEvent::isNotClicked(header,window))
    {
        options.enableStates(Hidden);
    }
    options.eventHandler(window,event);
}
void Menu::update()
{

}

//void Menu::eventHandler(sf::RenderWindow &window, sf::Event event)
//{
//
//}


void Menu::draw(sf::RenderTarget &window, sf::RenderStates states) const
{
    window.draw(header);
    if(!options.checkState(Hidden))
    {
        window.draw(options);
    }

}

sf::FloatRect Menu::getGlobalBounds() const
{
    return header.getGlobalBounds();
}

void Menu::setPosition(sf::Vector2f position)
{
    header.setPosition(position);
    Position::boxBelow(header, options,20);

}
Snapshot* Menu::getSnapshot()
{

}
void Menu::applySnapshot(const Snapshot *snapshot)
{

}