//
// Created by tianh on 3/23/2023.
//

#ifndef SFML_PROJECT_ALLBOXES_H
#define SFML_PROJECT_ALLBOXES_H

#include "Box.h"
#include <vector>


class AllBoxes: public sf::Drawable, public States
{
private:
    std::vector<Box> allBoxes;

//    std::vector<std::string> names= {"menu", "start", "end"};
//    Box box;

public:
    AllBoxes();
    void push(const std::string& name);
    void setPosition(sf::Vector2f position);
    void eventHandler(sf::RenderWindow& window, sf::Event event);
    virtual void draw(sf::RenderTarget& window, sf::RenderStates states) const;
    sf::FloatRect getGlobalBounds() const;
};


#endif //SFML_PROJECT_ALLBOXES_H
