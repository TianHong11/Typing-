//
// Created by tianh on 3/18/2023.
//


#ifndef SFML_PROJECT_MOUSEEVENT_CPP
#define SFML_PROJECT_MOUSEEVENT_CPP
#include "MouseEvent.h"

template<class T>
bool MouseEvent::isHovered(const T &obj, sf::RenderWindow& window) {
    // sf::Mouse::getPosition(window) means if the mouse is in the window
    //// object.getGlobalBounds.contains((sf::Vector2f) not sure the meaning of this
    return  obj.getGlobalBounds().contains((sf::Vector2f)sf::Mouse::getPosition(window));
    //sf::Mouse::isButtonPressed(sf::Mouse::Left)
}

template<class T>
bool MouseEvent::isClicked(const T &obj, sf::RenderWindow &window) {
    //return  sf::Mouse::isButtonPressed(sf::Mouse::Left) && obj.getGlobalBounds().contains((sf::Vector2f)sf::Mouse::getPosition(window)) ;
    return isHovered(obj, window) && sf::Mouse::isButtonPressed(sf::Mouse::Left);

}
template<class T>
bool MouseEvent::isNotClicked(const T&obj, sf::RenderWindow& window)
{
    return !isHovered(obj, window) && sf::Mouse::isButtonPressed(sf::Mouse::Left);

}

//bool MouseEvent::mouseClickedWindow(sf::RenderWindow &window, sf::Event event) {
//    return sf::Mouse::isButtonPressed(sf::Mouse::Left) && window.isOpen();
//}


#endif //SFML_PROJECT_MOUSEEVENT_CPP


//bool MouseEvent::mouseDoubleClicked() {
//    return false;
//}
//
//
//void MouseEvent::countClicks(sf::Event event) {
//
//}
