//
// Created by tianh on 3/19/2023.
//
#ifndef SFML_PROJECT_POSITION_CPP
#define SFML_PROJECT_POSITION_CPP
#include "Position.h"

template<typename T>
void Position::centerText(const T &obj, sf::Text &text)
{
    sf::FloatRect textRect = text.getGlobalBounds();
    sf::FloatRect tRect = obj.getGlobalBounds();
    sf::Vector2f center = {textRect.width / 2.0f, textRect.height / 2.f};
    sf::Vector2f localBounds = {center.x + text.getLocalBounds().left, center.y + text.getLocalBounds().top};
    sf::Vector2f rounded = {std::round(localBounds.x), std::round(localBounds.y)};
    text.setOrigin(rounded);
    text.setPosition({tRect.left + tRect.width / 2, tRect.top + tRect.height / 2});
}

template<typename T, typename S>
void Position::boxBelow(const T &leftB, S &rightB, float space)
{
    sf::FloatRect l= leftB.getGlobalBounds();
    sf::FloatRect r= rightB.getGlobalBounds();
    rightB.setPosition({l.left, l.top + l.height + space});

}
template <typename T, typename S>
void Position::belowCursor(const T &cursor, S &words)
{
    sf::FloatRect c= cursor.getGlobalBounds();
    sf::FloatRect w= words.getGlobalBounds();
    words.setPosition({c.left+ w.width/2, c.top + c.height + w.height});
}


template <typename T, typename S>
void Position::iconLeft(const T& box1, S& icon)
{
    sf::FloatRect b= box1.getGlobalBounds();
    sf::FloatRect i= icon.getGlobalBounds();
    icon.setPosition({b.left+i.left, b.top + i.height/2});
}

template<typename T, typename S>
void Position::boxRight(const T &box1, S &box2, float space)
{
    sf::FloatRect b1= box1.getGlobalBounds();
    sf::FloatRect b2= box2.getGlobalBounds();

    box2.setPosition({b1.left+b1.width+space, b1.top});
}

template<typename T, typename S>
void Position::cursorBehindLast(const T &typing, S &cursor)
{
    sf::Vector2f t= typing.getLastPosition;
    sf::FloatRect c= cursor.getGlobalBounds();
    cursor.setPosition({t.x, t.y+c.width});
}

#endif //SFML_PROJECT_POSITION_CPP