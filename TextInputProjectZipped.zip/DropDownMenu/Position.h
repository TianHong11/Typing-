//
// Created by tianh on 3/19/2023.
//

#ifndef SFML_PROJECT_POSITION_H
#define SFML_PROJECT_POSITION_H

#include <SFML/Graphics.hpp>
#include <iostream>
#include <cmath>
#include "../Typing.h"

class Position
{
public:
    template <typename T>
    static void centerText(const T &obj, sf::Text &text);
    template <typename T, typename S>
    static void boxBelow(const T& box1, S& box2, float space);
    template <typename T, typename S>
    static void boxRight(const T& box1, S& box2, float space);


    template <typename T, typename S>
    static void iconLeft(const T& box1, S& icon);


    template <typename T, typename S>
    static void cursorBehindLast(const T& typing, S& cursor);

    template <typename T, typename S>
    static void belowCursor(const T& cursor, S& words);
};

#include "Position.cpp"
#endif //SFML_PROJECT_POSITION_H
