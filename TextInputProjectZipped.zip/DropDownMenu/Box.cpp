//
// Created by tianh on 3/23/2023.
//

#include "Box.h"

Box::Box()
{

}

Box::Box(const std::string& name)
{
    setText(name);
    setBox();
}

void Box::setText(const std::string &name)
{

    text.setFont(Font::getFont());
    text.setString(name);
    text.setFillColor(theColor);
    text.setCharacterSize(36);

}

void Box::setBox()
{
    box.setSize({200,50});
    box.setFillColor(background);
    Position::centerText(box, text);

}

void Box::eventHandler(sf::RenderWindow &window, sf::Event event)
{
    if(MouseEvent::isHovered(box, window))
    {
        box.setFillColor(theColor);
        text.setFillColor(background);
    }
    else
    {
        box.setFillColor(background);
        text.setFillColor(theColor);
    }
}

void Box::setPosition(sf::Vector2f position)
{
    box.setPosition(position);
    Position::centerText(box, text);

}

sf::Vector2f Box::getTextPosition()
{
    return text.getPosition();
}

sf::FloatRect Box::getGlobalBounds() const
{

    return box.getGlobalBounds();

}

void Box::draw(sf::RenderTarget &window, sf::RenderStates states) const
{
    window.draw(box);
    window.draw(text);
}