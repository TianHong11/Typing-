#include <iostream>
#include <SFML/Graphics.hpp>
//#include "ApplicationDave.h"
#include "Application.h"

int main() {

    Application a;
    a.run();

//    ApplicationDave app;
//    Circle circle;
//    circle.setRadius(50);

//   sf::RectangleShape square({50, 50});
//   square.setPosition({100, 100});

//    app.addDrawable(circle);
//   app.addDrawable(square);
//    app.run();
    return 0;
}
