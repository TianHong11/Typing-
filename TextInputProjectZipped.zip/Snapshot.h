//
// Created by tianh on 3/16/2023.
//

#ifndef SFML_PROJECT_SNAPSHOT_H
#define SFML_PROJECT_SNAPSHOT_H


class Snapshot
{
public:
//    virtual ~Snapshot();
//
//    virtual Snapshot* getSnapshot()=0;
//
//    virtual void applySnapshot(Snapshot* snapshot)=0;
    virtual void f() {};
};


#endif //SFML_PROJECT_SNAPSHOT_H
