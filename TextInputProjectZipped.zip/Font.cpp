//
// Created by tianh on 3/19/2023.
//

#include "Font.h"

sf::Font Font::font;
void Font::loadFont()
{
    font.loadFromFile("Font/Times New Roman.ttf");
}

sf::Font &Font::getFont()
{
    loadFont();
    return font;
}

const sf::Glyph &Font::getGlyph(char ch, int size)
{
    return font.getGlyph(ch, size, false);
}
