//
// Created by tianh on 4/4/2023.
//

#ifndef SFML_PROJECT_FILENODE_H
#define SFML_PROJECT_FILENODE_H


class FileNode {

};


#endif //SFML_PROJECT_FILENODE_H
