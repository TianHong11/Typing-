//
// Created by tianh on 4/4/2023.
//

#include "FileItem.h"

FileItem::FileItem() {

}

FileItem::FileItem(const std::string& imagePath, const std::string& text, sf::Vector2f& position)
{
//    setIcon(imagePath);
//
//    setText(text);
//    setPosition(position); //Box position changed

}

void FileItem::setIcon(std::string& imagePath)
{
    icon.setTexture(Image::getTexture(imagePath));
    icon.setScale({40, 40});
}

void FileItem::addEventHandler(sf::RenderWindow &window, sf::Event event)
{
    Box::getGlobalBounds();
}

sf::FloatRect FileItem::getGlobalBounds() const {
    return Box::getGlobalBounds();
}

sf::Vector2f FileItem::getSize() const {
    return sf::Vector2f();
}

sf::Vector2f FileItem::getPosition() const {
    return sf::Vector2f();
}

void FileItem::setPosition(sf::Vector2f pos) {
//    Box::setPosition(pos);
//    Position::iconLeft(Box::, icon);
}

void FileItem::draw(sf::RenderTarget &window, sf::RenderStates states) const
{
    window.draw(icon);
    Box::draw(window,states);
}
//void FileItem::setIcon(Image::image icon) {
//
//}
