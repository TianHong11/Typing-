//
// Created by tianh on 4/4/2023.
//

#ifndef SFML_PROJECT_IMAGE_H
#define SFML_PROJECT_IMAGE_H

#include <SFML/Graphics.hpp>
class Image
{
private:
    static sf::Texture texture;
    static void loadTexture(const std::string& theImage);
public:
    static sf::Texture& getTexture(const std::string& theImage);

};


#endif //SFML_PROJECT_IMAGE_H
