//
// Created by tianh on 4/4/2023.
//

#include "Image.h"

sf::Texture Image::texture;
void Image::loadTexture(const std::string& theImage)
{
    texture.loadFromFile(theImage);
}

sf::Texture &Image::getTexture(const std::string& theImage)
{
    loadTexture(theImage);
    return texture;
}
