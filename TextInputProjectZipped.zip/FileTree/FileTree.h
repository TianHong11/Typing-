//
// Created by tianh on 4/4/2023.
//

#ifndef SFML_PROJECT_FILETREE_H
#define SFML_PROJECT_FILETREE_H


class FileTree
{

};


#endif //SFML_PROJECT_FILETREE_H
