//
// Created by tianh on 3/18/2023.
//

#ifndef SFML_PROJECT_KEYBOARD_SHORTCUT_H
#define SFML_PROJECT_KEYBOARD_SHORTCUT_H

#include <SFML/Graphics.hpp>
class Keyboard_Shortcut
{
public:
    static bool isUndo();
};


#endif //SFML_PROJECT_KEYBOARD_SHORTCUT_H
