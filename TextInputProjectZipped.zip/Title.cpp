//
// Created by tianh on 3/20/2023.
//

#include "Title.h"



Title::Title()
{
    setFont(Font::getFont());
    setCharacterSize(24);
}

//Title::Title()
//{
//    text.setFillColor(sf::Color::Blue);
////    text.setCharacterSize(24);
//    text.setFont(Font::getFont());
//}

//void Title::setPosition(float x, float y)
//{
//    text.setPosition(x,y);
//}
//
//void Title::setSize(int size)
//{
//    text.setCharacterSize(size);
//}
//
//void Title::setString(std::string name)
//{
//    text.setString(name);
//}
//
//void Title::draw(sf::RenderTarget &window, sf::RenderStates states) const
//{
//    window.draw(text);
//}
