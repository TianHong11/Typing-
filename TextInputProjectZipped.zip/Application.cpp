//
// Created by tianh on 3/19/2023.
//

#include "Application.h"

Application::Application()
{
}

void Application::run()
{
    sf::RenderWindow window(sf::VideoMode(1000, 700, 32), "Test");
    window.setFramerateLimit(60);
    window.setVerticalSyncEnabled(false);

    TextInput ti;
    ti.setLabel("Name: ");

//    sf::Vector2f pos= {200,200};
//    FileItem fileItem("FileTree/file.png", "Directory", pos);

    WordSort ws("5000-baby-girl-names.txt", ti);
    ws.setPosition({120,100});

//    Position::belowCursor(ti, ws); ////why is not working?

//    WordSort s("List");
//    s.setPosition({200,200});

//    Menu menu({"menu","start", "end"});
//    Menu menu2({"Setting", "Volume", "Language"});
//    Menu menu3({"Player","1", "2"});
//
//    Position::boxRight(menu, menu2, 30);
//    Position::boxRight(menu2, menu3, 30);


    ti.setPosition(50,50);

    while(window.isOpen())
    {
        sf::Event event{};
        while(window.pollEvent(event)){
            if (event.type == sf::Event::Closed){
                window.close();
            }

            ti.addEventHandler(window, event);
//            History::eventHandler(window,event);
//            fileItem.addEventHandler(window,event);

            if(event.type == sf::Event::TextEntered)
            {
                ws.priority(ti.getString());

            }

//            menu.addEventHandler(window,event);
//            menu2.addEventHandler(window, event);
//            menu3.addEventHandler(window,event);
        }
//        Position::belowCursor(ti, ws);
        ws.setPosition({120,100});

        ti.update();

        window.clear(sf::Color::Black);
        window.draw(ti);
        window.draw(ws);

//        window.draw(fileItem);



//        window.draw(menu);
//        window.draw(menu2);
//        window.draw(menu3);
        window.display();
    }
}
