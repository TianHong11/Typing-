//
// Created by tianh on 3/19/2023.
//

#ifndef SFML_PROJECT_FONT_H
#define SFML_PROJECT_FONT_H

#include <SFML/Graphics.hpp>
class Font
{
private:
    static sf::Font font;
    static void loadFont();

public:
    static sf::Font& getFont();
    static const sf::Glyph &getGlyph(char ch, int size);
};



#endif //SFML_PROJECT_FONT_H
