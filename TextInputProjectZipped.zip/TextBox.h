//
// Created by tianh on 3/20/2023.
//

#ifndef SFML_PROJECT_TEXTBOX_H
#define SFML_PROJECT_TEXTBOX_H
#include "GUIComponent.h"
#include <SFML/Graphics.hpp>
class TextBox: public sf::RectangleShape
{
public:
    TextBox();

};


#endif //SFML_PROJECT_TEXTBOX_H
