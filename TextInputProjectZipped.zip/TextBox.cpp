//
// Created by tianh on 3/20/2023.
//

#include "TextBox.h"

TextBox::TextBox()
{
    setSize({700, 30});
    setFillColor(sf::Color::Transparent);
    setOutlineThickness(1.f);

}
